<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Login::index');
$routes->add('/login', 'Login::index');
$routes->post('/login/auth', 'Login::auth');
$routes->get('/login/logout', 'Login::logout');

$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/add-offer', 'Dashboard::addoffer');
$routes->get('/edit-offer/(:num)', 'Dashboard::addoffer/$1');

$routes->get('api/offers', 'api\Offer::listOffers');
$routes->post('api/addOffer', 'api\Offer::addOffer');
$routes->post('/api/updateOffer/(:num)', 'api\Offer::updateOffer/$1');
$routes->delete('/api/deleteOffer/(:num)', 'api\Offer::deleteOffer/$1');
$routes->post('/api/updateOfferStatus/(:num)', 'api\Offer::updateOfferStatus/$1');

