<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->add('/login', 'Login::index');
$routes->post('/login/auth', 'Login::auth');
$routes->get('/login/logout', 'Login::logout');

$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/add-offer', 'Dashboard::addoffer');

$routes->get('api/offers', 'api\Offer::listOffers');
$routes->post('api/addOffer', 'api\Offer::addOffer');

