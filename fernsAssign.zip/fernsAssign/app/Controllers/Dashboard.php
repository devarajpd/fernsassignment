<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Dashboard extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }
        return view('dashboard');
        // echo 'Welcome to your Dashboard, ' . session()->get('username') . '!';
        // echo '<br><a href="/login/logout">Logout</a>';
    }
    public function addoffer()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }
        return view('addoffer');
    }
}
