<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\OfferModel;

class Dashboard extends BaseController
{
    protected $offerModel;

    public function __construct()
    {
        $this->offerModel = new OfferModel();
    }
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }
        return view('dashboard');
    }
    public function addoffer($id = null)
    {
        if ($id) {
            $offer = $this->offerModel->find($id);
            if ($offer) 
            {
                return view('addoffer', ['offer' => $offer]);
            } else 
            {
                return redirect()->to('/dashboard')->with('error', 'Offer not found.');
            }
        }
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }
        return view('addoffer');
    }
}
