<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;

class Login extends BaseController
{
    //use ResponseTrait;
    public function index()
    {
        return view('login');
    }
    public function auth()
    {
        helper('jwt'); 
        
        $session = session();
        $model = new UserModel();
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $model->getUserByUsername($username);

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $token = createJWT([
                    'id' => $user['id'],
                    'username' => $user['username'],
                ]);
                $sessionData = [
                    'id'       => $user['id'],
                    'username' => $user['username'],
                    'logged_in' => true,
                    'token'     => $token
                ];
                $session->set($sessionData);
                return redirect()->to('/dashboard');
            } else {
                $session->setFlashdata('msg', 'Incorrect Password');
                return redirect()->to('/login');
            }
        } else {
            $session->setFlashdata('msg', 'Invalid Username');
            return redirect()->to('/login');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
