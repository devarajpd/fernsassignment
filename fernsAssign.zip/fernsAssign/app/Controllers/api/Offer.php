<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use CodeIgniter\RESTful\ResourceController;

use App\Models\OfferModel;
use CodeIgniter\API\ResponseTrait;

class Offer extends BaseController
{
    use ResponseTrait;

    protected $offerModel;

    public function __construct()
    {
        $this->offerModel = new OfferModel();
    }

    public function index()
    {
        //
    }
    public function addOffer()
    {
        helper('jwt');
        $authHeader = $this->request->getHeaderLine('Authorization');

        if (!$authHeader) {
            return $this->respond([
                'status' => false,
                'message' => 'Authorization header missing.'
            ], 401);
        }
    
        list($type, $token) = explode(' ', $authHeader);
    
        if (strtolower($type) !== 'bearer' || empty($token)) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid Authorization header format.'
            ], 401);
        }
        $decoded = validateJWT($token);

        if (!$decoded) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid or expired token.'
            ], 401);
        }
        $image = $this->request->getFile('image');
        $imageName = '';
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $imageName = $image->getRandomName();
            $image->move('uploads/offers/', $imageName);
        }
        $offerData = [
            'offerCode' => $this->request->getPost('offerCode'),
            'expiryDate' => $this->request->getPost('expiryDate'),
            'minimumSpend' => $this->request->getPost('minimumSpend'),
            'amount' => $this->request->getPost('amount'),
            'image' => $imageName,
            'status' => $this->request->getPost('status'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            'deleted_at' => 10,
        ];
        if ($this->offerModel->insert($offerData)) {
            return $this->respond([
                'status' => true,
                'message' => 'Offer added successfully.',
            ], 201); // 201 Created
        } else {
            return $this->respond([
                'status' => false,
                'message' => 'Failed to add offer.',
            ], 500); // 500 Internal Server Error
        }
    }
    public function updateOffer($id)
    {
    helper('jwt');

    $authHeader = $this->request->getHeaderLine('Authorization');
    if (!$authHeader) {
        return $this->respond(['status' => false, 'message' => 'Authorization header missing.'], 401);
    }

    list($type, $token) = explode(' ', $authHeader);
    if (strtolower($type) !== 'bearer' || empty($token)) {
        return $this->respond(['status' => false, 'message' => 'Invalid Authorization header format.'], 401);
    }

    $decoded = validateJWT($token);
    if (!$decoded) {
        return $this->respond(['status' => false, 'message' => 'Invalid or expired token.'], 401);
    }

    $offer = $this->offerModel->find($id);
    if (!$offer) {
        return $this->respond(['status' => false, 'message' => 'Offer not found.'], 404);
    }

    $image = $this->request->getFile('image');
    $imageName = $offer['image'];
    if ($image && $image->isValid() && !$image->hasMoved()) {
        $imageName = $image->getRandomName();
        $image->move('uploads/offers/', $imageName);
    }

    $updateData = [
        'offerCode' => $this->request->getPost('offerCode'),
        'expiryDate' => $this->request->getPost('expiryDate'),
        'minimumSpend' => $this->request->getPost('minimumSpend'),
        'amount' => $this->request->getPost('amount'),
        'status' => $offer['status'],
        'image' => $imageName,
        'updated_at' => date('Y-m-d H:i:s'),
    ];

    if ($this->offerModel->update($id, $updateData)) {
        return $this->respond(['status' => true, 'message' => 'Offer updated successfully.'], 200);
    } else {
        return $this->respond(['status' => false, 'message' => 'Failed to update offer.'], 500);
    }
}
public function deleteOffer($id)
{
    helper('jwt');

    $authHeader = $this->request->getHeaderLine('Authorization');
    if (!$authHeader) {
        return $this->respond(['status' => false, 'message' => 'Authorization header missing.'], 401);
    }

    list($type, $token) = explode(' ', $authHeader);
    if (strtolower($type) !== 'bearer' || empty($token)) {
        return $this->respond(['status' => false, 'message' => 'Invalid Authorization header format.'], 401);
    }

    $decoded = validateJWT($token);
    if (!$decoded) {
        return $this->respond(['status' => false, 'message' => 'Invalid or expired token.'], 401);
    }

    $offer = $this->offerModel->find($id);

    if (!$offer) {
        return $this->respond(['status' => false, 'message' => 'Offer not found.'], 404);
    }

    if ($this->offerModel->delete($id)) {
        return $this->respond(['status' => true, 'message' => 'Offer deleted successfully.'], 200);
    } else {
        return $this->respond(['status' => false, 'message' => 'Failed to delete offer.'], 500);
    }
}
public function updateOfferStatus($id)
{
    helper('jwt');

    $authHeader = $this->request->getHeaderLine('Authorization');
    if (!$authHeader) {
        return $this->respond(['status' => false, 'message' => 'Authorization header missing.'], 401);
    }

    list($type, $token) = explode(' ', $authHeader);
    if (strtolower($type) !== 'bearer' || empty($token)) {
        return $this->respond(['status' => false, 'message' => 'Invalid Authorization header format.'], 401);
    }

    $decoded = validateJWT($token);
    if (!$decoded) {
        return $this->respond(['status' => false, 'message' => 'Invalid or expired token.'], 401);
    }

    $status = $this->request->getPost('status');

    if (!in_array($status, ['0', '1'])) {
        return $this->respond(['status' => false, 'message' => 'Invalid status value.'], 400);
    }

    if ($this->offerModel->update($id, ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')])) {
        return $this->respond(['status' => true, 'message' => 'Offer status updated successfully.']);
    } else {
        return $this->respond(['status' => false, 'message' => 'Failed to update offer status.'], 500);
    }
}
    public function listOffers()
    {
        helper('jwt');
        $authHeader = $this->request->getHeaderLine('Authorization');

        if (!$authHeader) {
            return $this->respond([
                'status' => false,
                'message' => 'Authorization header missing.'
            ], 401);
        }
    
        list($type, $token) = explode(' ', $authHeader);
    
        if (strtolower($type) !== 'bearer' || empty($token)) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid Authorization header format.'
            ], 401);
        }
        $decoded = validateJWT($token);

        if (!$decoded) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid or expired token.'
            ], 401);
        }
        
        $offers = $this->offerModel
            ->where('deleted_at', 10) 
            ->findAll();

        return $this->respond([
            'status' => true,
            'message' => 'Offers fetched successfully.',
            'data' => $offers
        ], 200);
    }
}
