<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

use CodeIgniter\RESTful\ResourceController;

use App\Models\OfferModel;
use CodeIgniter\API\ResponseTrait;

class Offer extends BaseController
{
    use ResponseTrait;

    protected $offerModel;

    public function __construct()
    {
        $this->offerModel = new OfferModel();
    }

    public function index()
    {
        //
    }
    public function addOffer()
    {
        helper('jwt');
        $authHeader = $this->request->getHeaderLine('Authorization');

        if (!$authHeader) {
            return $this->respond([
                'status' => false,
                'message' => 'Authorization header missing.'
            ], 401);
        }
    
        list($type, $token) = explode(' ', $authHeader);
    
        if (strtolower($type) !== 'bearer' || empty($token)) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid Authorization header format.'
            ], 401);
        }
        $decoded = validateJWT($token);

        if (!$decoded) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid or expired token.'
            ], 401);
        }

        echo $this->request->getPost('offerCode');exit;
        $offerData = [
            'offerCode' => $this->request->getPost('offerCode'),
            'expiryDate' => $this->request->getPost('expiryDate'),
            'minimumSpend' => $this->request->getPost('minimumSpend'),
            'amount' => $this->request->getPost('amount'),
            'image' => '',
            'status' => $this->request->getPost('status'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
echo $offerData;exit;
        // Insert the offer into the database
        if ($this->offerModel->insert($offerData)) {
            return $this->respond([
                'status' => true,
                'message' => 'Offer added successfully.',
            ], 201); // 201 Created
        } else {
            return $this->respond([
                'status' => false,
                'message' => 'Failed to add offer.',
            ], 500); // 500 Internal Server Error
        }
    }
    public function listOffers()
    {
        helper('jwt');
        $authHeader = $this->request->getHeaderLine('Authorization');

        if (!$authHeader) {
            return $this->respond([
                'status' => false,
                'message' => 'Authorization header missing.'
            ], 401);
        }
    
        list($type, $token) = explode(' ', $authHeader);
    
        if (strtolower($type) !== 'bearer' || empty($token)) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid Authorization header format.'
            ], 401);
        }
        $decoded = validateJWT($token);

        if (!$decoded) {
            return $this->respond([
                'status' => false,
                'message' => 'Invalid or expired token.'
            ], 401);
        }
        
        $offers = $this->offerModel
            //->where('status', 1) 
            ->findAll();

        return $this->respond([
            'status' => true,
            'message' => 'Offers fetched successfully.',
            'data' => $offers
        ], 200);
    }
}
