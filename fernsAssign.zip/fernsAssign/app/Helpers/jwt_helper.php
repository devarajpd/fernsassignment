<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

function createJWT($data)
{
    $key = getenv('JWT_SECRET');
    $issuedAt = time();
    $expirationTime = $issuedAt + 3600; // Token valid for 1 hour

    $payload = array(
        'iat' => $issuedAt,
        'exp' => $expirationTime,
        'data' => $data
    );

    return JWT::encode($payload, $key, 'HS256');
}

function validateJWT($token)
{
    try {
        $decoded = JWT::decode($token, new Key(getenv('JWT_SECRET'), 'HS256'));
        return (array) $decoded->data;
    } catch (Exception $e) {
        return null;
    }
}
