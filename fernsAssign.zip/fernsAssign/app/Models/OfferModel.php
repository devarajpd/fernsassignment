<?php

namespace App\Models;

use CodeIgniter\Model;

class OfferModel extends Model
{
    protected $table = 'offers'; // your table name
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType = 'array'; // or 'object' if you prefer

    protected $useSoftDeletes = false; // You are using `deleted_at` but it's INT, not DATETIME, so not CodeIgniter's soft delete standard

    protected $allowedFields = [
        'offerCode',
        'expiryDate',
        'minimumSpend',
        'amount',
        'image',
        'created_at',
        'updated_at',
        'deleted_at',
        'status'
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at'; // Normally for soft deletes, but your `deleted_at` is an INT

    // Validation (optional, if you want to use CI4 validation here)
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;
}
