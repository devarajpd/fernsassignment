<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Simple Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <style>
    body {
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      padding-top: 20px;
    }
    .sidebar a {
      color: #adb5bd;
      display: block;
      padding: 10px 20px;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }
    .topbar {
      background-color: #fff;
      padding: 10px 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .content {
      padding: 20px;
    }
  </style>
</head>

<body>

<div class="container-fluid">
  <div class="row">
    
    <!-- Sidebar -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="sidebar-sticky">
        <h5 class="text-white">Dashboard</h5>
        <a href="http://localhost:8080/dashboard">Home</a>
        <a href="http://localhost:8080/add-offer">Add Offer</a>
        <a href="http://localhost:8080/dashboard">List All Offers</a>
        <a href="http://localhost:8080/logout">Logout</a>
      </div>
    </nav>

    <!-- Main content -->
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      
      <div class="topbar d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Welcome to Dashboard</h4>
        <a href="/login/logout" class="btn btn-danger btn-sm">Logout</a>
      </div>

      <div class="content mt-4">
        <h5><?= isset($offer) ? 'Edit' : 'Add' ?> Offer</h5>
        <form id="addOfferForm" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= isset($offer) ? $offer['id'] : '' ?>">
          <div class="form-group">
            <label for="offerTitle">Offer Code</label>
            <input type="text" class="form-control"  id="offerCode" name="offerCode" required value="<?= isset($offer) ? $offer['offerCode'] : '' ?>">
          </div>
          <div class="form-group">
            <label for="expiryDate">Offer Expiry Date</label>
            <input type="date" class="form-control"  id="expiryDate" name="expiryDate" required value="<?= isset($offer) ? $offer['expiryDate'] : '' ?>" >
          </div>
          <div class="form-group">
            <label for="expiryDate">Minimum Spend</label>
            <input type="text" class="form-control" id="minimumSpend" name="minimumSpend" required value="<?= isset($offer) ? $offer['minimumSpend'] : '' ?>">
          </div>
          <div class="form-group">
            <label for="expiryDate">Amount</label>
            <input type="text" class="form-control" id="amount" name="amount" required value="<?= isset($offer) ? $offer['amount'] : '' ?>" >
          </div>
          <div class="form-group">
            <input type="file" id="image" name="image" accept="image/*">
            <input type="hidden"  id="status"   name="status" value="1">
          </div>
          <button type="submit" class="btn btn-primary"><?= isset($offer) ? 'Update' : 'Add' ?> Offer</button>
        </form>
      </div>

    </main>

  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#addOfferForm').submit(function(event) {
            event.preventDefault(); 

            const token = "<?= session('token') ?>"; 
            const formData = new FormData(this);
            const id = $('input[name="id"]').val();
            let apiurl = '';

              if (id === '') {
                  apiurl = 'http://localhost:8080/api/addOffer';
              } else {
                  apiurl = 'http://localhost:8080/api/updateOffer/' + id;
              }

            $.ajax({
                url: apiurl,
                type: 'POST',
                headers: {
                'Authorization': 'Bearer ' + token,
                },
                data: formData, 
                processData: false, 
                contentType: false, 
                success: function(response) {
                    alert(response.message);
                    if (id == '') {
                        $('#addOfferForm')[0].reset();
                    }
                     
                },
                error: function(error) {
                    alert('Error: ' + error.responseJSON.message); 
                }
            });
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
