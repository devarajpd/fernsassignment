<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Simple Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <style>
    body {
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      padding-top: 20px;
    }
    .sidebar a {
      color: #adb5bd;
      display: block;
      padding: 10px 20px;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }
    .topbar {
      background-color: #fff;
      padding: 10px 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .content {
      padding: 20px;
    }
  </style>
    <style>
    body {
      background-color: #f8f9fa;
      font-family: Arial, sans-serif;
    }
    .table thead th {
      background-color: #343a40;
      color: white;
    }
    .action-buttons button {
      margin-right: 5px;
    }
  </style>
</head>

<body>

<div class="container-fluid">
  <div class="row">
    
    <!-- Sidebar -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="sidebar-sticky">
        <h5 class="text-white">Dashboard</h5>
        <a href="http://localhost:8080/dashboard">Home</a>
        <a href="http://localhost:8080/add-offer">Add Offer</a>
        <a href="http://localhost:8080/dashboard">List All Offers</a>
        <a href="http://localhost:8080/logout">Logout</a>
      </div>
    </nav>

    <!-- Main content -->
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      
      <div class="topbar d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Welcome to Dashboard</h4>
        <a href="/login/logout" class="btn btn-danger btn-sm">Logout</a>
      </div>

  <div class="container content mt-4">
  <h5>List all Offers</h5>
  <table id="offersTable" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Offer Code</th>
            <th>Expiry Date</th>
            <th>Minimum Spend</th>
            <th>Amount</th>
            <th>Image</th>
            <th>Created At</th>
            <th>Actions</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <!-- Data will be dynamically inserted here -->
    </tbody>
</table>
</div>

<script>
  function confirmDelete(id) {
    if (confirm("Are you sure you want to delete offer #" + id + "?")) {
      // Redirect or AJAX call to delete offer
      window.location.href = "/delete-offer/" + id;
    }
  }
</script>

    </main>

  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        function fetchProtectedData() {
            const token = "<?= session('token') ?>"; // Get token from PHP session

            $.ajax({
                url: 'http://localhost:8080/api/offers',
                type: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                success: function(data) {
                    console.log(data);
                    if (data.status && data.data.length > 0) {
                        let tableContent = '';
                        data.data.forEach(function(offer) {
                            tableContent += `
                                <tr id="offer-${offer.id}">
                                    <td>${offer.id}</td>
                                    <td>${offer.offerCode}</td>
                                    <td>${offer.expiryDate}</td>
                                    <td>${offer.minimumSpend}</td>
                                    <td>${offer.amount}</td>
                                    <td>${offer.image ? `<img src="${offer.image}" alt="Offer Image" width="50" height="50">` : 'No Image'}</td>
                                    <td>${offer.created_at}</td>
                                    <td class="action-buttons">
                                      <a  href="/edit-offer/${offer.id}" class="btn btn-primary btn-sm">Edit</a>
                                      <button  onclick="confirmDelete(${offer.id})" class="btn btn-danger btn-sm">Delete</button>
                                    </td>
                                    <td>
                                        ${
                                            offer.status == 1 
                                            ? '<button class="btn btn-sm btn-success">Active</button>' 
                                            : '<button class="btn btn-sm btn-secondary">Inactive</button>'
                                        }
                                    </td>
                                </tr>
                            `;
                        });

                        
                        $('#offersTable tbody').html(tableContent);
                    } else {
                        console.error('No offers found or invalid data.');
                    }
                },
                error: function(error) {
                    console.error("Error fetching data: ", error);
                }
            });
        }

        fetchProtectedData();
    });

    function confirmDelete(id) {
        if (confirm("Are you sure you want to delete this offer?")) {
          const row = document.getElementById(`offer-${id}`);
          if (row) { row.style.display = 'none'; }
        }
       
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
