<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Simple Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <style>
    body {
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      padding-top: 20px;
    }
    .sidebar a {
      color: #adb5bd;
      display: block;
      padding: 10px 20px;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }
    .topbar {
      background-color: #fff;
      padding: 10px 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .content {
      padding: 20px;
    }
    body {
      background-color: #f8f9fa;
      font-family: Arial, sans-serif;
    }
    .table thead th {
      background-color: #343a40;
      color: white;
    }
    .action-buttons button {
      margin-right: 5px;
    }
    .switch {
    display: inline-block;
    margin-bottom: .5rem;
}

.switch-button {
    /* background color when "off" */
    background: #FFFFFF;

    /* size of switch */
    width: 43px;
    height: 25px;
    border: 2px solid #E6E6E6;
    border-radius: 100px;
    display: block;

    cursor: pointer;
    -webkit-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;
    outline: 0;
    -webkit-transition: all .4s ease;
    -o-transition: all .4s ease;
    transition: all .4s ease;
}

/* Style of the "bubble" that toggles */
.switch-button::after {
    /* size of bubble */
    width: 21px;
    height: 21px;
    border-radius: 50%;
    background-color: #FFFFFF;
    position: relative;
    display: block;
    content: "";
    -webkit-transition: tranform .4s cubic-bezier(0.175, 0.885, 0.320, 1.275), 
                padding .3s ease, margin .3s ease;
    -o-transition: tranform .4s cubic-bezier(0.175, 0.885, 0.320, 1.275), 
                padding .3s ease, margin .3s ease;
    transition: tranform .4s cubic-bezier(0.175, 0.885, 0.320, 1.275), 
                padding .3s ease, margin .3s ease;
    -webkit-transform: translateX(0);
        -ms-transform: translateX(0);
            transform: translateX(0);
    -webkit-box-shadow: 0 1px 3px rgba(0,0,0,.4);
            box-shadow: 0 1px 3px rgba(0,0,0,.4);
}

.switch-input {
    display: none;
}

.switch-button:hover::after {
    will-change: padding;
}

.switch-button:active::after {
    padding-right: .4rem;
}

/* "On" state
   ========================== */

.switch-input:checked + .switch-button {
    /* border and background color when the button is "on" */
    border-color: var(--highlight); 
    background: var(--highlight);
}

.switch-input:checked + .switch-button::after {
    /* bubble position when "on" */
    -webkit-transform: translateX(18px);
        -ms-transform: translateX(18px);
            transform: translateX(18px);
}

.switch-input:checked + .switch-button:active::after {
    margin-left: -.4rem;
}

/* Checkbox in disabled state
   ========================== */

.switch-input[type="checkbox"]:disabled + .switch-button {
    opacity: .6;
    cursor: not-allowed;
    -webkit-box-shadow: 0 0 0 transparent;
            box-shadow: 0 0 0 transparent;
}

.switch-input[type="checkbox"]:checked:disabled + .switch-button {
    /* border and background color when button is disabled */
    border-color: #cccccc;
    background: #cccccc;
}
  </style>
</head>

<body>

<div class="container-fluid">
  <div class="row">
    
    <!-- Sidebar -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="sidebar-sticky">
        <h5 class="text-white">Dashboard</h5>
        <a href="http://localhost:8080/dashboard">Home</a>
        <a href="http://localhost:8080/add-offer">Add Offer</a>
        <a href="http://localhost:8080/dashboard">List All Offers</a>
        <a href="http://localhost:8080/logout">Logout</a>
      </div>
    </nav>

    <!-- Main content -->
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      
      <div class="topbar d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Welcome to Dashboard</h4>
        <a href="/login/logout" class="btn btn-danger btn-sm">Logout</a>
      </div>

  <div class="container content mt-4">
  <h5>List all Offers</h5>
  <table id="offersTable" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Offer Code</th>
            <th>Expiry Date</th>
            <th>Minimum Spend</th>
            <th>Amount</th>
            <th>Image</th>
            <th>Created At</th>
            <th>Actions</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <!-- Data will be dynamically inserted here -->
    </tbody>
</table>
</div>

<script>
  function confirmDelete(id) {
    if (confirm("Are you sure you want to delete offer #" + id + "?")) {
      // Redirect or AJAX call to delete offer
      window.location.href = "/delete-offer/" + id;
    }
  }
</script>

    </main>

  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        function fetchProtectedData() {
            const token = "<?= session('token') ?>"; // Get token from PHP session

            $.ajax({
                url: 'http://localhost:8080/api/offers',
                type: 'GET',
                headers: {
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                success: function(data) {
                    console.log(data);
                    if (data.status && data.data.length > 0) {
                        let tableContent = '';
                        data.data.forEach(function(offer) {
                            tableContent += `
                                <tr id="offer-${offer.id}">
                                    <td>${offer.id}</td>
                                    <td>${offer.offerCode}</td>
                                    <td>${offer.expiryDate}</td>
                                    <td>${offer.minimumSpend}</td>
                                    <td>${offer.amount}</td>
                                    <td>${offer.image ? `<img src="uploads/offers/${offer.image}" alt="Offer Image" width="50" height="50">` : 'No Image'}</td>
                                    <td>${offer.created_at}</td>
                                    <td class="action-buttons">
                                      <a  href="/edit-offer/${offer.id}" class="btn btn-primary btn-sm">Edit</a>
                                      <button  onclick="confirmDelete(${offer.id})" class="btn btn-danger btn-sm">Delete</button>
                                    </td>
                                    <td>
                                    <div ng-app="ods-widgets">
                                        <label class="switch">
                                            <input class="switch-input" type="checkbox" onchange="updateStatus(this, ${offer.id})"  ${offer.status == 1 ? 'checked' : ''}>
                                            <span class="switch-button"  title="${offer.status == 1 ? 'Active Offer' : 'InActive Offer'}"></span>
                                        </label>
                                    </div>
                                    </td>
                                </tr>
                            `;
                        });

                        
                        $('#offersTable tbody').html(tableContent);
                    } else {
                        console.error('No offers found or invalid data.');
                    }
                },
                error: function(error) {
                    console.error("Error fetching data: ", error);
                }
            });
        }

        fetchProtectedData();
    });
    function confirmDelete(id) {   
    
    const token = "<?= session('token') ?>";
    if (confirm('Are you sure you want to delete this offer?')) {
        $.ajax({
            url: 'http://localhost:8080/api/deleteOffer/' + id,
            type: 'DELETE',
            headers: {
                'Authorization': 'Bearer ' + token
            },
            success: function(response) {
              const row = document.getElementById(`offer-${id}`);
              if (row) { row.style.display = 'none'; }
                alert(response.message);
                // Reload or refresh offer list here if needed
                fetchProtectedData(); // If you have a function to reload
            },
            error: function(error) {
                alert('Error: ' + (error.responseJSON ? error.responseJSON.message : 'Something went wrong'));
            }
        });
    }
}

function updateStatus(checkbox, id) {
    const token = "<?= session('token') ?>"; // your session token

    const newStatus = checkbox.checked ? 1 : 0; // 1 = Active, 0 = Inactive

    $.ajax({
        url: 'http://localhost:8080/api/updateOfferStatus/' + id,
        type: 'POST',
        headers: {
            'Authorization': 'Bearer ' + token
        },
        data: {
            status: newStatus
        },
        success: function(response) {
            alert(response.message);
        },
        error: function(error) {
            alert('Error: ' + (error.responseJSON ? error.responseJSON.message : 'Something went wrong'));
            checkbox.checked = !checkbox.checked; // rollback if error
        }
    });
}

</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
